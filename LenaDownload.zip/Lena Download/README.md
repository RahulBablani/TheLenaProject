# Running Lena
- open *executable* folder
- simply double click *LENA.jar*
- or in line command: *java -jar LENA.jar*

# How to edit jar (for furture releases)
- open *read_for_jar* folder
- add new class files that are to be included in the update
- in line command:
	- cd into *read_for_jar* folder
	- run: *jar cfm LENA.jar MANIFEST.MF*
- optional: delete .class files & MANIFEST.MF