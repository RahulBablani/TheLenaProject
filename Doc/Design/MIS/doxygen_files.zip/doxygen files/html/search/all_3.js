var searchData=
[
  ['getopenfile',['getOpenFile',['../class_file_explorer.html#a50fa4b9fe6be9144dcdd59147232b950',1,'FileExplorer']]],
  ['getsavefile',['getSaveFile',['../class_file_explorer.html#a4e9ba5206d62870e8707d72dadfc4706',1,'FileExplorer']]]
];
