var searchData=
[
  ['imageloader',['imageLoader',['../class_lena_processing.html#adf8f8983fc5a74522895b06ae0f6cdb1',1,'LenaProcessing']]]
];
