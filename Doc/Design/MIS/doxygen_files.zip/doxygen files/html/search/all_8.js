var searchData=
[
  ['saveaction',['saveAction',['../class_file_explorer.html#ad2471a494884ef84895f973429c22316',1,'FileExplorer']]]
];
