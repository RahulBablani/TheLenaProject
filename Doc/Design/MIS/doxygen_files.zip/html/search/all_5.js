var searchData=
[
  ['lenamain',['LenaMain',['../class_lena_main.html',1,'']]],
  ['lenaprocessing',['LenaProcessing',['../class_lena_processing.html',1,'LenaProcessing'],['../class_lena_processing.html#af9eee76dee4500ac068764b1cbf13ae6',1,'LenaProcessing.LenaProcessing()']]]
];
